module.exports = 'CLE_SECRETE_CLIENT'
