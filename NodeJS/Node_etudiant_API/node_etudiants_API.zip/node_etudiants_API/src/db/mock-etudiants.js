const etudiants = [
  {
    "id": 2,
    "lastname": "Durand",
    "firstname": "Marie",
    "gender": "f",
    "city": "Lille",
    "country": "France",
    "created": "2025-06-04T09:34:30.702Z"
  },
  {
    "id": 3,
    "lastname": "Demaison",
    "firstname": "Julie",
    "gender": "f",
    "city": "Bordeaux",
    "country": "France",
    "created": "2025-06-04T09:34:30.702Z"
  },
  {
    "id": 4,
    "lastname": "Diongue",
    "firstname": "Ngone",
    "gender": "f",
    "city": "thiaroye",
    "country": "Sénégal",
    "created": "2025-06-04T09:34:30.702Z",
    "updated": "2025-06-04T10:04:13.451Z"
  },
  {
    "id": 5,
    "lastname": "Diallo",
    "firstname": "Abdou",
    "gender": "m",
    "city": "Abidjan",
    "country": "Cote d ivoire",
    "created": "2025-06-04T09:34:30.702Z"
  },
  {
    "id": 6,
    "lastname": "Zola",
    "firstname": "Margo",
    "gender": "f",
    "city": "Reims",
    "country": "France",
    "created": "2025-06-04T09:34:30.702Z"
  },
  {
    "id": 7,
    "lastname": "Beltazare",
    "firstname": "Marine",
    "gender": "f",
    "city": "Strasbourg",
    "country": "France",
    "created": "2025-06-04T09:34:30.702Z"
  },
  {
    "id": 8,
    "lastname": "Berbardot",
    "firstname": "Helene",
    "gender": "f",
    "city": "Nantes",
    "country": "France",
    "created": "2025-06-04T09:34:30.702Z"
  },
  {
    "id": 9,
    "lastname": "Elghayeb",
    "firstname": "Ahmed",
    "gender": "m",
    "city": "Alger",
    "country": "Algerie",
    "created": "2025-06-04T09:34:30.702Z"
  },
  {
    "id": 10,
    "lastname": "Michelet",
    "firstname": "Karen",
    "gender": "f",
    "city": "Nice",
    "country": "France",
    "created": "2025-06-04T09:34:30.702Z"
  },
  {
    "lastname": "Nogaye",
    "firstname": "Diagne",
    "gender": "f",
    "city": "Paris",
    "country": "France",
    "id": 11,
    "created": "2025-06-04T09:34:30.702Z"
  },
  {
    "lastname": "Diagne",
    "firstname": "Nogaye",
    "gender": "f",
    "city": "Paris",
    "country": "France",
    "id": 12,
    "created": "2025-06-04T09:34:56.231Z"
  },
  {
    "lastname": "Diongue",
    "firstname": "Ngone",
    "gender": "f",
    "city": "Ouakam",
    "country": "Sénégal",
    "id": 13,
    "created": "2025-06-04T09:37:46.177Z"
  }
];

module.exports = etudiants;