=============
version 1 
===========
Mouhamed DIAGNE
=+===========
Tache fini : AfficherTousLesEquipes et AfficherUneEquipes 
======



======================
les regles



============== équipe ===================
ne pas accepter 2 equipes avec le meme id : Fait






========================== matches=======================
1)un matches est identifieé par un couple d'id celle de l'equipe 1 et equipe 2 : Fait

2)ne pas avoir le meme match 2 fois par exemple
 on peut pas avoir deux fois un match PSG-Ol mais on pey avoir PSG-Ol et Ol-PSG: Fait

3)un équipe doit exister dans équipes avnt d'exister dans matches sinon ça passe pas : Fait