module.exports = [
  {
    "id": "PSG",
    "nom": "Paris",
    "ville": "Paris",
    "stade": "Parc des Princes",
    "entraineur": "Luis Enrique",
    "Modified": "2025-06-04T22:12:11.770Z"
  },
  {
    "id": "OM",
    "nom": "Marseille",
    "ville": "Marseille",
    "stade": "Stade Vélodrome",
    "entraineur": "Igor Tudor"
  },
  {
    "id": "OGCN",
    "nom": "Nice",
    "ville": "Nice",
    "stade": "Stade de Nice",
    "entraineur": "Pino Blood",
    "Created": "2025-06-04T20:42:37.293Z"
  }
];