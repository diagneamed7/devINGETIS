module.exports = [
  {
    "id": "1",
    "dateDuMatch": "2023-10-03",
    "heureDuMatch": "15:00",
    "idEquipeRecevante": "PSG",
    "idEquipeDeplacée": "OM",
    "butsEquipeRecevante": 2,
    "butsEquipeDeplacée": 1,
    "etatDuMatch": "terminé",
    "remarques": "Paris gagne contre Marseille"
  },
  {
    "id": "3",
    "dateDuMatch": "2023-10-09",
    "heureDuMatch": "20:00",
    "idEquipeRecevante": "OM",
    "idEquipeDeplacée": "OL",
    "butsEquipeRecevante": 4,
    "butsEquipeDeplacée": 2,
    "etatDuMatch": "terminé",
    "remarques": "Score modifié, match spectaculaire !",
    "Modified": "2025-06-05T22:34:29.044Z"
  },
  {
    "id": "4",
    "dateDuMatch": "2025-06-05",
    "heureDuMatch": "22:11",
    "idEquipeRecevante": "PSG",
    "idEquipeDeplacée": "OM",
    "butsEquipeRecevante": 2,
    "butsEquipeDeplacée": 1,
    "etatDuMatch": "terminé",
    "remarques": "Match très disputé"
  }
];