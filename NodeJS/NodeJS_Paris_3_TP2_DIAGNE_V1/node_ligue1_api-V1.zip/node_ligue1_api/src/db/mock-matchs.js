const matchs = [
  {
    dateDuMatch: "2023-10-03",
    heureDuMatch: "15:00",
    idEquipeRecevante: "PSG",
    idEquipeDeplacée: "OM",
    butsEquipeRecevante: 2,
    butsEquipeDeplacée: 1,
    etatDuMatch: "terminé",
    remarques: "Paris gagne contre Marseille",
  },
  {
    dateDuMatch: "2023-10-06",
    heureDuMatch: "17:00",
    idEquipeRecevante: "OL",
    idEquipeDeplacée: "PSG",
    butsEquipeRecevante: 1,
    butsEquipeDeplacée: 3,
    etatDuMatch: "terminé",
    remarques: "Paris s'impose à Lyon",
  },
  {
    dateDuMatch: "2023-10-09",
    heureDuMatch: "20:00",
    idEquipeRecevante: "OM",
    idEquipeDeplacée: "OL",
    butsEquipeRecevante: 0,
    butsEquipeDeplacée: 2,
    etatDuMatch: "terminé",
    remarques: "Lyon gagne à Marseille",
  }
];

module.exports = matchs;