const equipes = [
  {
    "id": "PSG",
    "nom": 'Paris',
    "ville": 'Paris',
    "stade":"Parc des Princes",
    "entraineur": "Christophe Galtier"
  },
 {
    "id": "OM",
    "nom": 'Marseille',
    "ville": 'Marseille',
    "stade":"Stade Vélodrome",
    "entraineur": "Igor Tudor"
  },
 {
    "id": "OL",
    "nom": 'Lyon',
    "ville": 'Lyon',
    "stade":"Groupama Stadium",
    "entraineur": "Laurent Blanc"
  },

];
module.exports = equipes;