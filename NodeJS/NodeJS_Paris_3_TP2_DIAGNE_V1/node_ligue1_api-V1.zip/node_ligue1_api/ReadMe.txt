=============
version 1 
===========
Mouhamed DIAGNE
=+===========
Tache fini : AfficherTousLesEquipes et AfficherUneEquipes 
======